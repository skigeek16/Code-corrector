```
def shortest_paths(start, graph):
    distances = {node: float('infinity') for pair in graph for node in pair}
    distances[start] = 0
    queue = list(distances.keys())
    while queue:
        current_node = min(queue, key=lambda node: distances[node])
        queue.remove(current_node)
        for neighbor, weight in [(node, graph[(current_node, node)]) for node in queue if (current_node, node) in graph]:
            distance = distances[current_node] + weight
            if distance < distances[neighbor]:
                distances[neighbor] = distance
    return distances
```