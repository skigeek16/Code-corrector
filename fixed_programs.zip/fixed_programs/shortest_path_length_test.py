```
def shortest_path_length(length_by_edge, start, end):
    INT_MAX = float('inf')
    distance = {node: INT_MAX for node in [start, end]}
    distance[start] = 0
    queue = [start]
    while queue:
        node = queue.pop(0)
        for neighbor, edge_length in [(n, length_by_edge.get((node, n), float('inf'))) for n in [n for n in [node.next] if n][0]]:
            new_distance = distance[node] + edge_length
            if new_distance < distance[neighbor]:
                distance[neighbor] = new_distance
                queue.append(neighbor)
    return distance[end] if distance[end] != INT_MAX else INT_MAX
```