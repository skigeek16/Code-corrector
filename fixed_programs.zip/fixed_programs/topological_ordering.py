def topological_ordering(nodes):
    visited = set()
    ordering = []

    def dfs(node):
        if node not in visited:
            visited.add(node)
            for next_node in node.outgoing_nodes:
                if next_node not in visited:
                    dfs(next_node)
            ordering.append(node)

    for node in nodes:
        if node not in visited:
            dfs(node)

    return ordering[::-1]