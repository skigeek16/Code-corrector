Here is the corrected code:

```python
def shortest_path_lengths(num_nodes, graph):
    shortest_distances = {node: float('inf') for node in range(num_nodes)}
    shortest_distances[0] = 0

    for _ in range(num_nodes - 1):
        for node1, node2 in graph:
            if shortest_distances[node1] + graph[(node1, node2)] < shortest_distances[node2]:
                shortest_distances[node2] = shortest_distances[node1] + graph[(node1, node2)]

    for node1, node2 in graph:
        if shortest_distances[node1] + graph[(node1, node2)] < shortest_distances[node2]:
            raise ValueError("Negative weight cycle detected")

    return shortest_distances
```