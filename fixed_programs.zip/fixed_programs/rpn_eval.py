```
def rpn_eval(tokens):
    def op(symbol, a, b):
        return {
            '+': lambda a, b: a + b,
            '-': lambda a, b: a - b,
            '*': lambda a, b: a * b,
            '/': lambda a, b: a / b
        }[symbol](a, b)

    stack = []
 
    for token in tokens:
        if isinstance(token, float):
            stack.append(token)
        else:
            if len(stack) < 2:
                raise ValueError('Not enough operands for operator')
            a = stack.pop()
            b = stack.pop()
            stack.append(
                op(token, b, a)
            )

    if len(stack) != 1:
        raise ValueError('Malformed RPN expression')
    return stack.pop()
```