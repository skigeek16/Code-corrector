```
def depth_first_search(start, end, visited=None):
    if visited is None:
        visited = set()
    visited.add(start.name)
    if start == end:
        return True
    for neighbour in start.successors:
        if neighbour.name not in visited:
            if depth_first_search(neighbour, end, visited):
                return True
    return False
```