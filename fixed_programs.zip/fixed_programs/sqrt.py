def sqrt(x, epsilon):
    approx = max(x / 2, 0.5)
    while abs(x - approx**2) > epsilon:
        approx = 0.5 * (approx + x / approx)
    return approx